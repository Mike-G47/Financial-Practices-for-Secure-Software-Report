package com.snhu.sslserver;

import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/hash")
public class HashController {

    private final HashService hashService;

    public HashController(HashService hashService) {
        this.hashService = hashService;
    }

    // GET /hash?data=...&name=...
    @GetMapping
    public Map<String, Object> hash(
            @RequestParam(value = "data", required = false, defaultValue = "Hello World Check Sum!") String data,
            @RequestParam(value = "name", required = false, defaultValue = "Mike G") String name
    ) {
        String checksum = hashService.sha256Hex(data);
        Map<String, Object> res = new LinkedHashMap<>();
        res.put("requestedBy", name);
        res.put("algorithm", "SHA-256");
        res.put("length_bits", 256);
        res.put("input", data);
        res.put("checksum", checksum);
        res.put("timestamp", hashService.timestamp());
        return res;
    }

    // POST /hash/verify  { "data": "...", "checksum": "..." }
    @PostMapping("/verify")
    public Map<String, Object> verify(@RequestBody VerifyRequest body) {
        String actual = hashService.sha256Hex(body.getData());
        boolean matches = actual.equalsIgnoreCase(body.getChecksum());
        Map<String, Object> res = new LinkedHashMap<>();
        res.put("algorithm", "SHA-256");
        res.put("input", body.getData());
        res.put("expected", body.getChecksum());
        res.put("actual", actual);
        res.put("matches", matches);
        res.put("timestamp", hashService.timestamp());
        return res;
    }

    public static class VerifyRequest {
        private String data;
        private String checksum;
        public String getData() { return data; }
        public void setData(String data) { this.data = data; }
        public String getChecksum() { return checksum; }
        public void setChecksum(String checksum) { this.checksum = checksum; }
    }
}